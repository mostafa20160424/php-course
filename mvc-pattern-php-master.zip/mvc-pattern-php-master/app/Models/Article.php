<?php

namespace App\Models;

/**
 * Model des articles
 */
class Article extends Model
{

}
