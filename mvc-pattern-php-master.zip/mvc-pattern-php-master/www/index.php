<?php

/**
 * Point d'entrée
 */

require __DIR__.'/../bootstrap/autoload.php';

$app = require __DIR__.'/../bootstrap/app.php';

$app->run();