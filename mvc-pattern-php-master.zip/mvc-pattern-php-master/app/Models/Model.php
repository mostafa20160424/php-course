<?php

namespace App\Models;

use Core\Model\BaseModel;

/**
 * Model parent
 */
abstract class Model extends BaseModel
{

}
