<?php

/**
 * Fichier de démarage
 * Charger tout ce que l'application a besoin avec l'autoloader
 * Charger liste des routes
 */

require_once __DIR__.'/../vendor/autoload.php';

require_once __DIR__.'/../app/routes.php';
