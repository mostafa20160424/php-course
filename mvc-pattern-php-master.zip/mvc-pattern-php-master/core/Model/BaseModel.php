<?php

namespace Core\Model;

/**
 * Model parent
 */
abstract class BaseModel
{

}
