<?php

namespace Core\Exception;

use Exception;

class ExceptionHandler extends Exception
{

}
