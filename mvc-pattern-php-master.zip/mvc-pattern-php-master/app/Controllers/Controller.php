<?php

namespace App\Controllers;

use Core\Controller\BaseController;

/**
 * Controlelr parent de l'application
 */
abstract class Controller extends BaseController
{

}
